// Minimal CSInterface implementation for CEP panels
function CSInterface() {}

CSInterface.prototype.evalScript = function(script, callback) {
    if (typeof __adobe_cep__ !== 'undefined' && __adobe_cep__.evalScript) {
        __adobe_cep__.evalScript(script, callback);
    } else {
        if (callback) {
            callback("MOCK_ERROR: Not running inside CEP environment");
        }
    }
};

CSInterface.prototype.getHostEnvironment = function() {
    if (typeof __adobe_cep__ !== 'undefined' && __adobe_cep__.getHostEnvironment) {
        return JSON.parse(__adobe_cep__.getHostEnvironment());
    }
    return {
        appName: "MOCK",
        appVersion: "1.0",
        appLocale: "es_ES",
        appSkinInfo: {
            panelBackgroundColor: {
                color: {
                    red: 18,
                    green: 18,
                    blue: 20,
                    alpha: 255
                }
            }
        }
    };
};

CSInterface.prototype.closeExtension = function() {
    if (typeof __adobe_cep__ !== 'undefined' && __adobe_cep__.closeExtension) {
        __adobe_cep__.closeExtension();
    }
};
