// ExtendScript for Adobe Premiere Pro, After Effects, and Photoshop
// Maxim to OBS Connection Script

function getActiveAppInfo() {
    var info = { app: app.name, hasActiveItem: false, itemName: "", detail: "" };
    try {
        if (app.name.indexOf("Premiere") !== -1) {
            info.app = "Premiere Pro";
            if (app.project && app.project.activeSequence) {
                info.hasActiveItem = true;
                info.itemName = app.project.activeSequence.name;
                info.detail = "Timecode: " + app.project.activeSequence.getPlayerPosition().formatted;
            } else {
                info.itemName = "Ninguna secuencia activa";
            }
        } else if (app.name.indexOf("After Effects") !== -1) {
            info.app = "After Effects";
            if (app.project && app.project.activeItem) {
                info.hasActiveItem = true;
                info.itemName = app.project.activeItem.name;
                info.detail = "Resolución: " + app.project.activeItem.width + "x" + app.project.activeItem.height;
            } else {
                info.itemName = "Ninguna composición activa";
            }
        } else if (app.name.indexOf("Photoshop") !== -1) {
            info.app = "Photoshop";
            if (app.documents.length > 0) {
                info.hasActiveItem = true;
                info.itemName = app.activeDocument.name;
                info.detail = "Tamaño: " + app.activeDocument.width + "x" + app.activeDocument.height + " (" + app.activeDocument.layers.length + " capas)";
            } else {
                info.itemName = "Ningún documento activo";
            }
        }
    } catch (e) {
        info.detail = "Error: " + e.toString();
    }
    return JSON.stringify(info);
}

function exportFrameToPath(folderPath) {
    try {
        if (app.name.indexOf("Photoshop") !== -1) {
            if (app.documents.length === 0) return "Error: No hay documento abierto.";
            var doc = app.activeDocument;
            var file = new File(folderPath + "/photoshop_obs_frame.png");
            var opts = new PNGSaveOptions();
            doc.saveAs(file, opts, true, Extension.LOWERCASE);
            return "Exportado: " + file.fsName;
        } else if (app.name.indexOf("Premiere") !== -1) {
            var seq = app.project.activeSequence;
            if (!seq) return "Error: No hay secuencia activa.";
            var time = seq.getPlayerPosition();
            var file = new File(folderPath + "/premiere_obs_frame.txt");
            file.open("w");
            file.write("Premiere Frame Sync: " + seq.name + " at ticks: " + time.ticks);
            file.close();
            return "Sincronizado: " + file.fsName;
        } else if (app.name.indexOf("After Effects") !== -1) {
            var comp = app.project.activeItem;
            if (!comp) return "Error: No hay composición activa.";
            var file = new File(folderPath + "/ae_obs_frame.txt");
            file.open("w");
            file.write("After Effects Sync: " + comp.name + " at time: " + comp.time);
            file.close();
            return "Sincronizado: " + file.fsName;
        }
    } catch (e) {
        return "Error al exportar: " + e.toString();
    }
    return "Aplicación no soportada.";
}
